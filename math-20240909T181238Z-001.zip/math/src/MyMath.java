import java.util.Scanner;

public class MyMath {
    static final float pi = 3.14f;
    final float e = 2.71f;
    int t = 0;
    static Scanner zxc = new Scanner(System.in);
    public static void minuschislo() {
        int a = zxc.nextInt();
        if (a > 0) {
            int b = a - 2 * a;
            System.out.println("Число: " + b);
        } else {
            int c = a - 2 * a;
            System.out.println("Число: " + c);
        }
    }

    public static void ctg(){
        System.out.println("Введите первый катет");
        int a = zxc.nextInt();
        System.out.println("Введите второй катет");
        int b = zxc.nextInt();
        System.out.println("Введите гипотенузу");
        int d = zxc.nextInt();
        int ctgg = (a+d)/(b+d);
        System.out.println("Котангенс = " + ctgg);
    }

    public static void dlina(){
        int r = zxc.nextInt();
        float L = 2*pi*r;
        System.out.println("Длина окружности: " + L);
    }

    public static void chisla(){

    }
}
